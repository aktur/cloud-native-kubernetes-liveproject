#!/bin/sh

npm start


